<h1>Interactive drunken circles</h1>

<h3>Instructions to Run Locally</h3>

Navigate to the project directory in your terminal.
<br>
$ webpack main.js bundle.js
<br>
$ open index.html
